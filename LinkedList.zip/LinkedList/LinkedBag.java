/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: LinkedBag.java
 * Author: Frank M. Carrano
 * Author: Timothy M. Henry
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment03PartA;
//instead of deleting the correct/right item, it delete the first all the way to th end

import java.util.*;
public final class LinkedBag<T> implements PrimaryDataStructureBagInterface<T> {

    private Node handle;
    private int numberOfEntries;

    public LinkedBag() {
        handle = null;
        numberOfEntries = 0;
    }
    //        PrimaryDataStructureBagInterface<String> csc220Bag = new LinkedBag<>();

    // removeAllOccurrences() (all Obj) , remove() (the latest Obj) , remove(T anEntry) (a certain Obj)

    // need more correction
    @Override
    public boolean removeAllOccurrences(T[][] entries) {
        System.out.println("[+] Removing 2D test array items from the bag. . .");
        T[] array = convertMatrixToArray(entries);
        // finish converting 2D array to 1D array
        //Node currentNode = handle.next.next;

        // started remove duplicated element
        System.out.println(" [-] Removing duplicates in 1D array. . .");
        T[] duplicateRemovedArray = removeDuplicate(array);


        System.out.print(" [>] The final 1D array now contains: " );//+ Arrays.toString(duplicateRemovedArray));
        // finish removing duplicated element
        for (T t : duplicateRemovedArray){
            System.out.print(t +" ");
        }
        System.out.println(" ");


        System.out.println(" [-] Removing the final 1D array items from the bag. . .");
        //testRemoving(); removing method has problems
        // remove 1D items from aBag
        // for (int i=0;i< duplicateRemovedArray.length;i++) {
        boolean isRemoved= remove1DFromBag(duplicateRemovedArray);
        //System.out.println("\n has his one is removed: "+isRemoved);


        return isRemoved;
    }
    // here have to return each value
    private boolean remove1DFromBag(T[] array1D) {


        /*
         * create a moving Node that moves from the handle all the way to the end of the list
         * create a currentNode that change all the time from items of array1D
         *
         * if this movingNode.data == currentNode
         * remove movingNode.data
         *
         * */
        ArrayList<Node> listOfNode = new ArrayList<>();

        Node movingNode = handle; // set movingNode initially equals to handle
        for (int i = 0; i < numberOfEntries; i++) {
            listOfNode.add(movingNode);
            movingNode = movingNode.next;


        }

        // successfully transform Node in aBag to ArrayList
        Node currentNode;
        boolean isRemoved=false;
        Node yo = new Node((T) "l");
        add(yo.data);
        for (T t : array1D) {
            currentNode = handle;
            int p = 0;
            //int o=0;


            while ((p < 19) && (currentNode != null)) {

                if ((t.equals(currentNode.data))) {
                    if (handle.data!=currentNode.data) {
                        isRemoved = remove(t);
                        //o++;
                    }else{
                        remove() ;
                    }
                    //testing



                }
                currentNode = currentNode.next;
                p++;

            }
        }

        return isRemoved;
    }



    // remove duplication
    public T[]removeDuplicate(T[] array) {


        /*

         * actually, create another array, have a loop that go thru original array, if an element from old array equals
         * to one of the new array then no add into new array

         */
        // int numberOfNoDuplicated;
        ArrayList<T> listOfNoDulicate = new ArrayList<>();
        for (T t : array) {
            if (!listOfNoDulicate.contains(t)) {
                listOfNoDulicate.add(t);

            }

        }
        T[] noDuplicated = (T[]) new Object[listOfNoDulicate.size()];
        for (int i=0;i<noDuplicated.length;i++){
            noDuplicated[i] = listOfNoDulicate.get(i);
        }

        return noDuplicated;



    }

    public int getFrequency(T oldEntry){
        int count=0;
        Node currentNode = handle;
        for (int i=0;i<numberOfEntries;i++){
            if (handle!= null) {
                if (oldEntry.equals(currentNode.data)) {
                    count++;
                    // } else {
                    currentNode = currentNode.next;
                }
            }
        }
        return count;

    }

    public  T[] convertMatrixToArray(T[][] entries) {
        int count=0;
        for (T[] entry : entries) {
            for (int i = 0; i < entry.length; i++) {
                count++;
            }
        }
        System.out.println(" [-] Converting 2D array to 1D. . .");
        int index=0;
        T[] array = (T[]) new Object[count];
        for (T[] entry : entries) {
            for (T t : entry) {
                array[index] = t;
                index++;
            }
        }
        return array;
    }

    public void remove(){
        //if we want to remove an element from the list, we must let this behind-element point to its front one
        //but in this method, we simply gonna remove the first/latest element, then we can just
        Node currentNode  = new Node(null);
        if (handle != null){
            currentNode.data = handle.data;
            handle = handle.next;
            numberOfEntries--;

        }
        //return  currentNode.data;
    }
    public boolean remove(T oldEntry){
        //create another Node (called currentNode) and set newEntry to be its data.
        //if this currentNode isn't null, meaning it is in the list already, then set the first value to it (the handle at that time)
        //then set the handle to be its next (front) value
        boolean define=false;
        Node currentNode = getNode(oldEntry);
        if (currentNode!=null) {

            currentNode.data = handle.data;


            handle = handle.next;
            numberOfEntries--;
            define=true;
        }
        return define;
    }public Node getNode(T anEntry){
        // repeatedly set currentNode to the first, then second, then third,etc position to compare with the data anEntry
        // later will let currentNode to the next Obj
        Node currentNode = handle;

        boolean define= false;
        while ((!define)&&(currentNode!=null)){
            if (anEntry.equals(currentNode.data)){
                define = true;

            }else{
                currentNode = currentNode.next;
            }

        }

        return currentNode;
    }

    @Override
    public int getCurrentSize() {
        return numberOfEntries;
    }

    @Override
    public boolean isEmpty() {
        return numberOfEntries > 0;
    }

    @Override
    public boolean add(T newEntry) {
        Node newNode = new Node(newEntry);
        newNode.next = handle;
        handle = newNode;
        numberOfEntries++;


        return true;
    }

    @Override

    public T[] toArray() {
        T[] ListOfT = (T[]) new Object[numberOfEntries];
        Node currentNode = handle; //must not directly equal to handle, else within this loop, every other element in the list will also be messed up

        for (int i =0;i<numberOfEntries;i++) {
            if (currentNode != null) {
                ListOfT[i] = currentNode.data;
                currentNode = currentNode.next;
            }
        }return ListOfT;
    }

    private class Node {
        private T data;
        private Node next;

        private Node(T dataPortion) {
            this(dataPortion, null);
        } // end constructor

        private Node(T dataPortion, Node nextNode) {
            data = dataPortion;
            next = nextNode;
        }
    }
}
